public interface Define {
    double GetDefine();
}
class Human implements Define{
    double height;
    public Human(double height){
        this.height = height;
    }
    @Override
    public double GetDefine(){
        return height;
    }


    public String toString() {
        return "Human's height: "+height;
    }
}

class Student extends Human{
    private int grade;
    public Student(double height,int grade){
        super(height);
        this.grade = grade;
    }
    public double GetDefine(){
        return grade;
    }

    public String toString() {
        return "student's height: "+height+" grade: "+grade;
    }
}
