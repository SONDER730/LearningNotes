package event;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.*;
import javax.swing.*;

public class SketchTest {
    public static void main(String[] args){
        SketchFrame f = new SketchFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
    }
}

class SketchFrame extends JFrame {
    public SketchFrame() {
        this.setTitle("Sketch Frame");
        this.setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        this.add(new SketchPanel());
    }

    public static final int DEFAULT_WIDTH = 400;
    public static final int DEFAULT_HEIGHT = 300;
}

class SketchPanel extends JPanel {
    public SketchPanel() {
        pl = new ArrayList<Line2D>();
        last = new Point2D.Double(100, 100);

        // Add KeyListener
        KeyHandler keyHandler = new KeyHandler();
        this.addKeyListener(keyHandler);

        // Add MouseListener
        MouseHandler mouseHandler = new MouseHandler();
        this.addMouseListener(mouseHandler);

        this.setFocusable(true);
    }

    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D)g;
        super.paintComponent(g2);

        for(Line2D l : pl) {
            g2.draw(l);
        }
    }

    public void add(int dx, int dy) {
        Point2D end = new Point2D.Double(last.getX() + dx, last.getY() + dy);
        Line2D l = new Line2D.Double(last, end);
        pl.add(l);
        last = end;
        repaint();
    }

    // New MouseHandler class to handle mouse clicks
    private class MouseHandler extends MouseAdapter {
        @Override
        public void mousePressed(MouseEvent e) {
            // Update the last point to where the mouse was clicked
            last = new Point2D.Double(e.getX(), e.getY());
            // Clear existing lines when starting from a new point (optional)
            // pl.clear();
            repaint();
        }
    }

    private class KeyHandler implements KeyListener {
        public void keyPressed(KeyEvent ke) {
            int c = ke.getKeyCode();
            int d = ke.isShiftDown() ? LARGE_INCRE : SMALL_INCRE;

            if(c == KeyEvent.VK_LEFT) add(-d, 0);
            else if(c == KeyEvent.VK_RIGHT) add(d, 0);
            else if(c == KeyEvent.VK_UP) add(0, -d);
            else if(c == KeyEvent.VK_DOWN) add(0, d);
        }

        public void keyReleased(KeyEvent ke) {
            // Not used but required by interface
        }

        public void keyTyped(KeyEvent ke) {
            char ch = ke.getKeyChar();
            int d = Character.isUpperCase(ch) ? LARGE_INCRE : SMALL_INCRE;
            ch = Character.toLowerCase(ch);

            if(ch == 'h') add(-d, 0);
            else if(ch == 'l') add(d, 0);
            else if(ch == 'k') add(0, -d);
            else if(ch == 'j') add(0, d);
        }
    }

    public static final int SMALL_INCRE = 1;
    public static final int LARGE_INCRE = 5;
    private ArrayList<Line2D> pl;
    private Point2D last;
}