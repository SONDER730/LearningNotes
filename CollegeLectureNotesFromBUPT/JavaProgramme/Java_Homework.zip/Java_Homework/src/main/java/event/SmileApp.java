package event;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

public class SmileApp {
    public static void main(String[] args) {
        SmileFrame frame = new SmileFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}

class SmileFrame extends JFrame {
    private SmilePanel smilePanel;

    public SmileFrame() {
        setTitle("Smile");
        setSize(400, 400);

        smilePanel = new SmilePanel();
        add(smilePanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton smileButton = new JButton("Smile");
        JButton bigSmileButton = new JButton("BigSmile");

        smileButton.addActionListener(e -> smilePanel.setSmileType(SmileType.NORMAL));
        bigSmileButton.addActionListener(e -> smilePanel.setSmileType(SmileType.BIG));

        buttonPanel.add(smileButton);
        buttonPanel.add(bigSmileButton);
        add(buttonPanel, BorderLayout.NORTH);

        KeyStroke ctrlB = KeyStroke.getKeyStroke(KeyEvent.VK_B, InputEvent.CTRL_DOWN_MASK);
        KeyStroke ctrlL = KeyStroke.getKeyStroke(KeyEvent.VK_L, InputEvent.CTRL_DOWN_MASK);

        getRootPane().registerKeyboardAction(
                e -> smilePanel.setSmileType(SmileType.BIG),
                ctrlB,
                JComponent.WHEN_IN_FOCUSED_WINDOW
        );

        getRootPane().registerKeyboardAction(
                e -> smilePanel.setSmileType(SmileType.NORMAL),
                ctrlL,
                JComponent.WHEN_IN_FOCUSED_WINDOW
        );
    }
}

enum SmileType {
    NORMAL,
    BIG
}

class SmilePanel extends JPanel {
    private SmileType currentSmile = SmileType.NORMAL;
    private Point startPoint = null;  // 存储笑容曲线的起点

    public SmilePanel() {
        setBackground(Color.WHITE);

        // 添加鼠标监听器
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                // 保存点击位置作为新的起点
                startPoint = new Point(e.getX(), e.getY());
                repaint();
            }
        });
    }
    public void setSmileType(SmileType type) {
        currentSmile = type;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int size = Math.min(getWidth(), getHeight()) * 3 / 4;
        int x = (getWidth() - size) / 2;
        int y = (getHeight() - size) / 2;

        //face
        g2.setColor(Color.YELLOW);
        g2.fill(new Ellipse2D.Double(x, y, size, size));
        g2.setColor(Color.BLACK);
        g2.draw(new Ellipse2D.Double(x, y, size, size));

        //eye
        int eyeSize = size / 10;
        g2.fill(new Ellipse2D.Double(x + size/3 - eyeSize/2, y + size/3, eyeSize, eyeSize));
        g2.fill(new Ellipse2D.Double(x + 2*size/3 - eyeSize/2, y + size/3, eyeSize, eyeSize));

        //mouth
        g2.setColor(Color.BLACK);
        if (startPoint != null) {
            if (currentSmile == SmileType.NORMAL) {
                QuadCurve2D smile = new QuadCurve2D.Double(
                        startPoint.x, startPoint.y,
                        startPoint.x + size/4, startPoint.y + size/4,
                        startPoint.x + size/2, startPoint.y
                );
                g2.draw(smile);
            } else {
                Path2D path = new Path2D.Double();
                path.moveTo(startPoint.x, startPoint.y);
                path.quadTo(
                        startPoint.x + size/4, startPoint.y + size/4,
                        startPoint.x + size/2, startPoint.y
                );
                path.closePath();
                g2.fill(path);
            }
        } else {
            if (currentSmile == SmileType.NORMAL) {
                Arc2D arc = new Arc2D.Double(x + size/4, y + size/3, size/2, size/2, 0, -180, Arc2D.OPEN);
                g2.draw(arc);
            } else {
                Arc2D arc = new Arc2D.Double(x + size/4, y + size/3, size/2, size/2, 0, -180, Arc2D.CHORD);
                g2.fill(arc);
            }
        }

        //text
        g2.setColor(Color.BLUE);
        g2.setFont(new Font("Arial", Font.ITALIC, 20));
        String text = (currentSmile == SmileType.NORMAL) ? "Smiling..." : "BigSmiling...";
        FontMetrics fm = g2.getFontMetrics();
        int textWidth = fm.stringWidth(text);
        g2.drawString(text, getWidth()/2 - textWidth/2, getHeight() - 20);
    }
}