import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CircleColorChange extends JFrame {
    private CirclePanel circlePanel;
    private JPanel buttonPanel;
    private JButton redButton, greenButton, blueButton;

    public CircleColorChange() {

        super("ColorTest");

        circlePanel = new CirclePanel();
        buttonPanel = new JPanel();

        redButton = new JButton("Red");
        greenButton = new JButton("Green");
        blueButton = new JButton("Blue");

        buttonPanel.setLayout(new FlowLayout());
        buttonPanel.add(redButton);
        buttonPanel.add(greenButton);
        buttonPanel.add(blueButton);

        setLayout(new BorderLayout());
        add(circlePanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        redButton.addActionListener(e -> circlePanel.setCircleColor(Color.RED));
        greenButton.addActionListener(e -> circlePanel.setCircleColor(Color.GREEN));
        blueButton.addActionListener(e -> circlePanel.setCircleColor(Color.BLUE));

        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    class CirclePanel extends JPanel {
        private Color circleColor;
        private int colorIndex = 0;
        private Color[] colors = {
                getBackground(),
                Color.RED,
                Color.GREEN,
                Color.BLUE
        };

        public CirclePanel() {
            circleColor = getBackground();

            setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {

                    if (isInsideCircle(e.getX(), e.getY())) {
                        colorIndex = (colorIndex + 1) % colors.length;
                        circleColor = colors[colorIndex];
                        repaint();
                    }
                }
            });
        }


        private boolean isInsideCircle(int x, int y) {
            int centerX = getWidth() / 2;
            int centerY = getHeight() / 2;
            int radius = Math.min(getWidth(), getHeight()) / 3;

            return Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2) <= Math.pow(radius, 2);
        }

        public void setCircleColor(Color color) {
            circleColor = color;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);


            int diameter = Math.min(getWidth(), getHeight()) / 2;
            int x = (getWidth() - diameter) / 2;
            int y = (getHeight() - diameter) / 2;

            g.setColor(circleColor);
            g.fillOval(x, y, diameter, diameter);

            g.setColor(Color.BLACK);
            g.drawOval(x, y, diameter, diameter);
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            CircleColorChange frame = new CircleColorChange();
            frame.setVisible(true);
        });
    }
}