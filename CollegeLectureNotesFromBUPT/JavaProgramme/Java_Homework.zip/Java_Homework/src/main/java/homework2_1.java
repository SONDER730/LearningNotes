public class homework2_1 {
    public static void main(String[] args){
        System.out.print("* |");
        for (int i=1;i<=9;i++){
            System.out.printf("%2d",i);
        }
        System.out.println("\n-------------------------------");
        for (int j=1;j<=9;j++){
            System.out.printf("%2d |",j);
            for (int k=1;k<=9;k++){
                System.out.printf("%2d ",k*j);
            }
            System.out.println();
        }

    }

}
