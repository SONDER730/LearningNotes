import java.time.LocalTime;
public class Timer {
    private int Hour;
    private int Minute;
    private boolean is24Format;

    public Timer(){
        LocalTime timeNow = LocalTime.now();
        this.Hour = timeNow.getHour();
        this.Minute = timeNow.getMinute();
        this.is24Format = true;
    }

    public Timer(int Hour,int Minute){
        this.Hour = Hour;
        this. Minute = Minute;
        this.is24Format = true;
    }

    public int searchHour(){
        return Hour;
    }

    public int searchMinute(){
        return Minute;
    }

    public void addOneHour(){
        Hour = (Hour+1) % 24;
    }

    public void addHour(int addtoHour){
        Hour = (Hour+addtoHour) % 24;
    }

    public void addOneMinute(){
        Minute = (Minute+1) % 60;
        if(Minute==0){
            addOneHour();
        }
    }

    public void addMinute(int addtoMinute){
        Minute = (Minute+addtoMinute) % 60;
        addHour(addtoMinute/60);
    }


    public void set12Format(){
        is24Format = false;
    }

    public void set24Format(){
        is24Format = true;
    }

    @Override
    public String toString() {
        if(is24Format){
            return String.format("%02d:%02d",Hour,Minute);
        }else{
            int displayHour = Hour % 12;
            if (displayHour == 0) displayHour=12;
            String period = (displayHour<12)?"AM":"PM";
            return String.format("%02d:%02d%s",Hour,Minute,period);
        }
    }
    public static void main(String[] args){
        //测试当前时间
        Timer timer = new Timer();

        System.out.println("使用当前时间");
        timer.set24Format();
        int TimeHour = timer.searchHour();
        System.out.println("能够访问时间的小时数:"+TimeHour);
        int TimeMinute = timer.searchMinute();
        System.out.println("能够访问时间的分钟数:"+TimeMinute);

        timer.addOneHour();
        System.out.println("能够将时间增加1小时:"+timer.toString());
        timer.addHour(5);
        System.out.println("能够将时间增加特定的小时:"+timer.toString());

        timer.addOneMinute();
        System.out.println("能够将时间增加1分钟:"+timer.toString());
        timer.addMinute(88);
        System.out.println("能够将时间增加特定的分钟:"+timer.toString());

        timer.set12Format();
        System.out.println("能够访问时间的小时数:"+timer.toString());
        System.out.println("能够访问时间的分钟数:"+timer.toString());

        timer.addOneHour();
        System.out.println("能够将时间增加1小时:"+timer.toString());
        timer.addHour(5);
        System.out.println("能够将时间增加特定的小时:"+timer.toString());

        timer.addOneMinute();
        System.out.println("能够将时间增加1分钟:"+timer.toString());
        timer.addMinute(88);
        System.out.println("能够将时间增加特定的分钟:"+timer.toString());


        System.out.println("使用特定时间：例如晚上九点半");
        Timer timer1 = new Timer(21,30);

        timer1.set24Format();

        timer1.addOneHour();
        System.out.println("能够将时间增加1小时:"+timer1.toString());
        timer1.addHour(5);
        System.out.println("能够将时间增加特定的小时:"+timer1.toString());

        timer1.addOneMinute();
        System.out.println("能够将时间增加1分钟:"+timer1.toString());
        timer1.addMinute(88);
        System.out.println("能够将时间增加特定的分钟:"+timer1.toString());

        timer1.set12Format();
        System.out.println("能够访问时间的小时数:"+timer1.toString());
        System.out.println("能够访问时间的分钟数:"+timer1.toString());

        timer1.addOneHour();
        System.out.println("能够将时间增加1小时:"+timer1.toString());
        timer1.addHour(5);
        System.out.println("能够将时间增加特定的小时:"+timer1.toString());

        timer1.addOneMinute();
        System.out.println("能够将时间增加1分钟:"+timer1.toString());
        timer1.addMinute(88);
        System.out.println("能够将时间增加特定的分钟:"+timer1.toString());

    }
}
