import java.util.Scanner;
public class experiment1_2 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while(true){
        System.out.print("input:");
        String sentence = scanner.nextLine();
        String[] words = sentence.split(" ");
        StringBuilder sub = new StringBuilder();
        sub.append(words[2].toUpperCase()).append(" ");
        for (int i = 3; i < words.length; i++) {
            sub.append(words[i]).append(" ");
//            System.out.println(words[i]);
        }
        sub.append(words[0].toLowerCase()).append(" ");
        sub.append(words[1]).append("?");
        for (int i=0;i<sub.length();i++){
            if (sub.charAt(i)=='.' || sub.charAt(i)=='!'){
                sub.setCharAt(i,',');
            }
        }
        System.out.println("output:" + sub.substring(0,1).toUpperCase()+sub.substring(1));

        }
    }
}