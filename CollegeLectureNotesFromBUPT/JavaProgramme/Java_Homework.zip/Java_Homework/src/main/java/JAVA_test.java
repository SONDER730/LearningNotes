public class JAVA_test {
    public abstract class Shape{
        public abstract double area();
        public abstract double perimeter();
        public abstract String toString();
    }

    public class Rectangle extends Shape{
        private double width;
        private double height;

        public Rectangle(double width,double height){
            this.height = height;
            this.width = width;
        }
        @Override
        public double area(){
            return 0.5*(height*width);
        }

        @Override
        public double perimeter(){
            return 0.5*(height+width);
        }

        @Override
        public String toString(){
            return "111";
        }


    }
//    public class Circle extends Shape{
//    }

    public static void main(String[] args) {

    }
}
