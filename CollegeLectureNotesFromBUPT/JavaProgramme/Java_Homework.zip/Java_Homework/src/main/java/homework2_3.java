import java.util.Scanner;
public class homework2_3 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a Binary string:");
        String binary = scanner.nextLine();
        try{
            int decimal = Integer.parseInt(binary,2);
            System.out.print("The equivalent decimal number for binary \""+binary+"\" is "+decimal);
        } catch (NumberFormatException e){
            System.out.print("Error: Invalid Binary String \""+binary+"\"");
        }
        scanner.close();

    }
}
