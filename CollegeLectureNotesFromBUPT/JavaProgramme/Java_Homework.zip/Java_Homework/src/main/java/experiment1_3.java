import java.util.Scanner;
import java.util.Calendar;

public class experiment1_3 {
    public static void printCal(int year, int month, int firstDayOfWeek, int totalDays , int day) {
        System.out.println("Mon Tue Wed Thu Fri Sat Sun");

        for (int i = 0; i < firstDayOfWeek; i++) {
            System.out.print("    ");
        }

        int currentDay = 1;
        int dayOfWeekCounter = firstDayOfWeek + 1;

        while (currentDay <= totalDays) {
            System.out.printf("%4d", currentDay);

            if (currentDay == day){
                System.out.print("*");
            }

            if (dayOfWeekCounter % 7 == 0) {
                System.out.println();
            }

            currentDay++;
            dayOfWeekCounter++;
        }

        if (dayOfWeekCounter % 7 != 1) {
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入出生日期，格式为 '2007 12 3'");

        int year = sc.nextInt();
        int month = sc.nextInt() - 1;
        int day = sc.nextInt();


        Calendar currentCal = Calendar.getInstance();
        int currentYear = currentCal.get(Calendar.YEAR);

        int[] weekCount = new int[7];

        for (int i = year; i <= currentYear; i++) {
            Calendar cal = Calendar.getInstance();
            cal.set(i, month, 1); // 设置为该年该月的第一天


            int firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
            if (firstDayOfWeek == 1){
                firstDayOfWeek = 8;
            }

            int totalDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

            cal.set(i, month, day);
            int birthdayWeekDay = cal.get(Calendar.DAY_OF_WEEK);
            if (birthdayWeekDay == 0){
                birthdayWeekDay = 8;
            }

            weekCount[birthdayWeekDay - 2]++;

            System.out.println(i);
            printCal(i, month + 1, firstDayOfWeek-2, totalDays,day);
        }


        System.out.println("\n生日所在的星期几的出现频率：");
        String[] weekDays = {"星期一", "星期二", "星期三", "星期四", "星期五", "星期六","星期日"};
        for (int i = 0; i < 7; i++) {
            double frequency = (double) weekCount[i] / (currentYear - year + 1);
            System.out.printf("%s: %.3f\n", weekDays[i], frequency );
        }

        sc.close();
    }
}
