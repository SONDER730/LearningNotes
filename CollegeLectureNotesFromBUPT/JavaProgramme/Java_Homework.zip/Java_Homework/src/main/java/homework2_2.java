import java.util.Scanner;
public class homework2_2 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an integer:");
        int num1 = scanner.nextInt();
        System.out.print("Enter a floating point number:");
        double num2 = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Enter your name:");
        String name = scanner.nextLine();
        double sum = num1 + num2;
        System.out.print("Hi! "+name+", the sum of "+ num1 +" and "+ num2 +" is " + sum);

    }
}
