import static java.lang.Math.*;
import java.util.Scanner;
public class experiment1_1 {
    public static class Circle{
        double radius;

        public Circle(double radius){
            this.radius = radius;
        }
        public double findArea(){
            return PI * radius *radius;
        }
    }
    public static class PassObject{
        public void printAreas(Circle c, int times){
            for(int i=1;i<=times;i++){
                c.radius = (double)i;
                System.out.printf("%.1f       %.15f\n",c.radius,c.findArea());
            }
        }
    }

    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int times = sc.nextInt();
        System.out.println("Radius        Area");

        PassObject test = new PassObject();
        Circle c = new Circle(1);
        test.printAreas(c,times);
    }
}
