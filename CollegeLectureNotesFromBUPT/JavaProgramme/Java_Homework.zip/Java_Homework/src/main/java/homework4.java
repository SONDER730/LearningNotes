public class homework4 {
    public static void main(String args[]){
        Human human = new Human("alice",7);
        Student student = new Student("charlie",15,"男");

        //poly
        Human polyHuman = new Student("David",16,"男");
        System.out.println(human);
        System.out.println(student);
        System.out.println(polyHuman);
        if (polyHuman instanceof Student){
            Student safeHuman = (Student) polyHuman;
            System.out.println("可以被安全转换类型："+safeHuman);
        }
    }
    public static class Human{
        protected String Name;
        protected int age;

        public Human(String Name,int age){
            this.age = age;
            this.Name = Name;
        }
        @Override
        public boolean equals(Object obj){
            if (this == obj) return true;
            if (obj == null || obj.getClass()!= getClass()) return false;
            Human human  = (Human) obj;
            return human.Name == this.Name && human.age == this.age;
        }
        @Override
        public String toString(){
            return "Name:"+Name+" Age:"+age;
        }
        @Override
        public int hashCode(){
            int result = 17;
            result = result*31+Name.hashCode();
            result = result*31+age;
            return result;
        }
    }
    public static class Student extends Human{
        private String sex;
        public Student(String Name,int age,String sex){
            super(Name,age);
            this.sex = sex;
        }
        @Override
        public boolean equals(Object obj){
            if (!super.equals(obj)) return false;
            Student student  = (Student) obj;
            return sex.equals(student.sex);
        }
        @Override
        public String toString(){
            return "Name:"+Name+" Age:"+age+" sex:"+sex;
        }
        @Override
        public int hashCode(){
            return super.hashCode()*31+sex.hashCode();
        }


    }
}
