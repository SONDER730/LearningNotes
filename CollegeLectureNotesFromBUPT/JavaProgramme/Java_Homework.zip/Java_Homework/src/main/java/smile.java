import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;

public class smile extends JComponent {
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;


        g2.setPaint(Color.YELLOW);
        Ellipse2D face = new Ellipse2D.Double(50, 50, 200, 200);
        g2.fill(face);


        g2.setPaint(Color.BLACK);
        Ellipse2D leftEye = new Ellipse2D.Double(90, 100, 20, 20);
        Ellipse2D rightEye = new Ellipse2D.Double(190, 100, 20, 20);
        g2.fill(leftEye);
        g2.fill(rightEye);

        g2.setStroke(new BasicStroke(3));
        Arc2D mouth = new Arc2D.Double(90, 130, 120, 60, 0, -180, Arc2D.OPEN);
        g2.draw(mouth);


        g2.setPaint(Color.BLACK);
        g2.setFont(new Font("Serif", Font.BOLD, 20));
        g2.drawString("Smiling...", 110, 280);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Smile");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.add(new smile());
            frame.setSize(300, 350);
            frame.setVisible(true);
        });
    }
}
