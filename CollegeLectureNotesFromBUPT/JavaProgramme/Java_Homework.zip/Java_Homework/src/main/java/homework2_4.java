import java.util.Scanner;
public class homework2_4 {
    public static void main(String[] args){
        String[] hexBits = {"0000", "0001", "0010", "0011",
                "0100", "0101", "0110", "0111",
                "1000", "1001", "1010", "1011",
                "1100", "1101", "1110", "1111"};

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a Hexadecimal string: ");
        String hex = scanner.nextLine();
        StringBuilder Binaryline = new StringBuilder();

        for (int i=0;i<hex.length();i++){
            int digit = Character.digit(hex.charAt(i),16);
            Binaryline.append(hexBits[digit]).append(" ");
        }

        System.out.print("The equivalent binary for hexadecimal \""+hex+"\" is "+Binaryline);
    }
}
