 /**
    Computes the average of a set of data values.
 */

 public class DataSet<T extends Define>
 {
    /**
       Constructs an empty data set.
    */

    private double sum;
    private T maximum;
    private int count;
    public DataSet()
    {
       sum = 0;
       count = 0;
       maximum = null;
    }
 
    /**
       Adds a data value to the data set
       @param item a data value
    */
    public void add(T item)
    {
       sum = sum + item.GetDefine();
       if (count == 0 || maximum==null || maximum.GetDefine() < item.GetDefine())
          maximum = item;
       count++;
    }
 
    /**
       Gets the average of the added data.
       @return the average or 0 if no data has been added
    */
    public double getAverage()
    {
       if (count == 0) return 0;
       else return sum / count;
    }
 
    /**
       Gets the largest of the added data.
       @return the maximum or 0 if no data has been added
    */
    public T getMaximum()
    {
       return maximum;
    }

    public static void main(String[] args) {
       DataSet<Human> HumanDS = new DataSet<>();
       HumanDS.add(new Human(1.67));
       HumanDS.add(new Human(1.95));
       HumanDS.add(new Human(1.46));
       System.out.println("输出平均值: "+HumanDS.getAverage());
       System.out.println("输出最大值: "+HumanDS.getMaximum());

       DataSet<Student> StudentDS = new DataSet<>();
       StudentDS.add(new Student(1.67,99));
       StudentDS.add(new Student(1.95,89));
       StudentDS.add(new Student(1.46,95));
       System.out.println("输出平均值: "+StudentDS.getAverage());
       System.out.println("输出最大值: "+StudentDS.getMaximum());
    }
 }

