import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Scanner;

public class pyh {

    // 将 Circle 声明为静态嵌套类，或将其移动到自己的文件中
    static class Circle {
        private double radius;

        public Circle(double radius) {
            this.radius = radius;
        }

        public double getRadius() {
            return radius;
        }

        public void setRadius(double radius) {
            this.radius = radius;
        }

        public double findArea() {
            return Math.PI * radius * radius;
        }
    }

    static class CircleUtils {
        public void printAreas(Circle circle, int times) {

            System.out.println("radius\tarea");
            for (int i = 1; i <= times; i++) {
                circle.setRadius(i);
                // 将面积格式化为 15 位小数
                BigDecimal area = new BigDecimal(circle.findArea());
                area = area.setScale(15, RoundingMode.HALF_UP);
                System.out.printf("%.1f\t%.15f%n", (double)i, area);
            }
        }
    }

    // 具有正确 main 方法签名的主方法
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int number = scanner.nextInt();
        Circle circle = new Circle(0);
        CircleUtils utils = new CircleUtils();
        utils.printAreas(circle, number);
        System.out.println("现在半径是 " + circle.getRadius());
    }
}
